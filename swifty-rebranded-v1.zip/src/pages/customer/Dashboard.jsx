import { useMemo } from 'react'
import { ArrowRight, Bell, MapPin, PackageCheck, Plus, Search } from 'lucide-react'
import { Link } from 'react-router-dom'
import { AppShell } from '../../components/app-shell'
import { ServiceActions } from '../../components/dashboard/ServiceActions'
import { ActiveRideCard } from '../../components/dashboard/ActiveRideCard'
import { useRequireAuth } from '../../lib/use-require-auth'
import { useStore } from '../../lib/mock-store'
import { MOCK_DASHBOARD_STATS } from '../../data/mock-data'

export default function CustomerDashboard() {
  const user = useRequireAuth('customer')
  const deliveries = useStore((s) => user ? s.deliveries.filter((d) => d.customerId === user.id) : [])
  const stats = useMemo(() => [
    { ...MOCK_DASHBOARD_STATS[0], value: '1', detail: '1 ride in progress' },
    { ...MOCK_DASHBOARD_STATS[1], value: String(deliveries.length), detail: `${deliveries.filter((d) => d.status !== 'delivered').length} still active` },
    { ...MOCK_DASHBOARD_STATS[2] },
  ], [deliveries.length])
  if (!user) return null
  const firstName = user.name.split(' ')[0]
  const recent = deliveries.slice(0, 3)

  return <AppShell>
    <main className="px-4 py-6 sm:px-6 lg:px-8">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        <section className="space-y-6">
          <div className="rounded-3xl bg-slate-950 p-6 text-white shadow-xl shadow-slate-900/10 sm:p-8">
            <div className="flex flex-col justify-between gap-8 sm:flex-row sm:items-end">
              <div><p className="text-sm font-medium text-emerald-300">Good to see you, {firstName}</p><h1 className="mt-2 max-w-xl font-display text-3xl font-black tracking-tight sm:text-4xl">Where can Swifty take you today?</h1><p className="mt-3 max-w-xl text-sm leading-6 text-slate-400">Ride across town, send a package, or track something already on its way.</p></div>
              <Link to="/customer/ride" className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-emerald-500 px-5 py-3 text-sm font-bold text-white transition hover:bg-emerald-400">Book a ride <ArrowRight className="h-4 w-4" /></Link>
            </div>
            <div className="mt-8 flex max-w-xl items-center gap-3 rounded-2xl bg-white/10 p-2 ring-1 ring-white/10"><Search className="ml-2 h-4 w-4 text-slate-400" /><input placeholder="Search destination, tracking ID or service" className="min-w-0 flex-1 bg-transparent px-1 py-2 text-sm text-white outline-none placeholder:text-slate-500" /><button className="rounded-xl bg-white px-4 py-2 text-xs font-bold text-slate-900">Search</button></div>
          </div>
          <ServiceActions />
          <ActiveRideCard />
          <section><div className="mb-3 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Your activity</p><h2 className="mt-1 font-display text-xl font-bold">Recent orders</h2></div><Link to="/customer/history" className="text-sm font-bold text-emerald-700">See all</Link></div><div className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200/70">{recent.length ? recent.map((item) => <Link key={item.id} to={`/customer/track/${item.id}`} className="flex items-center gap-4 border-b border-slate-100 p-4 last:border-0 hover:bg-slate-50"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700"><PackageCheck className="h-5 w-5" /></span><span className="min-w-0 flex-1"><span className="block text-sm font-bold">{item.pickup.address} → {item.dropoff.address}</span><span className="mt-1 block text-xs text-slate-500">{item.trackingId} · {item.status.replaceAll('_', ' ')}</span></span><ArrowRight className="h-4 w-4 text-slate-400" /></Link>) : <div className="p-8 text-center text-sm text-slate-500">Your recent orders will appear here.</div>}</div></section>
        </section>
        <aside className="space-y-4">
          <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200/70"><div className="flex items-center justify-between"><h2 className="font-display font-bold">Overview</h2><Link to="/customer/account" className="rounded-xl bg-slate-100 p-2 text-slate-500"><Plus className="h-4 w-4" /></Link></div><div className="mt-4 divide-y divide-slate-100">{stats.map((stat) => <div key={stat.label} className="py-4 first:pt-0 last:pb-0"><div className="flex items-end justify-between"><span className="text-sm text-slate-500">{stat.label}</span><strong className="font-display text-2xl">{stat.value}</strong></div><p className="mt-1 text-xs text-slate-400">{stat.detail}</p></div>)}</div></div>
          <div className="rounded-3xl bg-emerald-600 p-5 text-white shadow-lg shadow-emerald-600/15"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/15"><MapPin className="h-5 w-5" /></div><h3 className="mt-5 font-display text-lg font-bold">Save your favourite places</h3><p className="mt-2 text-sm leading-6 text-emerald-50">Add home, work and frequent destinations so every trip starts faster.</p><Link to="/customer/account" className="mt-5 inline-flex items-center gap-2 text-sm font-bold">Manage places <ArrowRight className="h-4 w-4" /></Link></div>
          <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200/70"><div className="flex gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-50 text-amber-700"><Bell className="h-5 w-5" /></div><div><h3 className="text-sm font-bold">Stay updated</h3><p className="mt-1 text-xs leading-5 text-slate-500">Turn on notifications for driver arrivals, package updates and important account alerts.</p></div></div></div>
        </aside>
      </div>
    </main>
  </AppShell>
}
