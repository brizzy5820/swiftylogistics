import { useState } from 'react'
import { ArrowLeft, CarFront, Check, MapPin, Navigation, Users } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { AppShell } from '../../components/app-shell'
import { useRequireAuth } from '../../lib/use-require-auth'
import { MOCK_RIDE_OPTIONS } from '../../data/mock-data'
import { createRide } from '../../services/api'

export default function Ride() {
  const user = useRequireAuth('customer')
  const navigate = useNavigate()
  const [option, setOption] = useState(MOCK_RIDE_OPTIONS[0])
  const [pickup, setPickup] = useState('Current location')
  const [dropoff, setDropoff] = useState('Victoria Island')
  const [loading, setLoading] = useState(false)
  if (!user) return null

  async function book() {
    setLoading(true)
    await createRide({ customerId: user.id, pickup, dropoff, rideType: option.id, fare: option.price })
    setLoading(false)
    navigate('/customer/history')
  }

  return <AppShell>
    <main className="mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[1.1fr_.9fr] lg:px-8">
      <section className="overflow-hidden rounded-3xl bg-emerald-50 p-6 sm:p-8">
        <Link to="/customer" className="mb-10 inline-flex items-center gap-2 text-sm font-bold text-slate-700"><ArrowLeft className="h-4 w-4" /> Dashboard</Link>
        <div className="max-w-lg"><p className="text-sm font-bold uppercase tracking-wider text-emerald-700">Ride with Swifty</p><h1 className="mt-2 font-display text-4xl font-black tracking-tight text-slate-950 sm:text-5xl">Where are you going?</h1><p className="mt-4 text-sm leading-6 text-slate-600">Choose a pickup, destination and ride type. This screen is mock-data driven and ready for the Express API.</p></div>
        <div className="mt-10 space-y-3 rounded-2xl bg-white p-4 shadow-sm">
          <Field icon={Navigation} value={pickup} onChange={setPickup} label="Pickup" />
          <div className="ml-2 h-4 border-l border-dashed border-slate-300" />
          <Field icon={MapPin} value={dropoff} onChange={setDropoff} label="Destination" dark />
        </div>
      </section>
      <section className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200/70 sm:p-6">
        <div className="flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Choose a ride</p><h2 className="mt-1 font-display text-xl font-bold">Available options</h2></div><CarFront className="h-5 w-5 text-emerald-600" /></div>
        <div className="mt-6 space-y-3">{MOCK_RIDE_OPTIONS.map((item) => <button key={item.id} onClick={() => setOption(item)} className={`flex w-full items-center gap-4 rounded-2xl p-4 text-left transition ${option.id === item.id ? 'bg-emerald-50 ring-2 ring-emerald-500' : 'bg-slate-50 ring-1 ring-slate-100 hover:bg-slate-100'}`}><div className="flex h-12 w-14 items-center justify-center rounded-xl bg-white shadow-sm"><CarFront className="h-6 w-6 text-slate-900" /></div><div className="min-w-0 flex-1"><p className="text-sm font-bold">{item.name}</p><p className="mt-1 text-xs text-slate-500">{item.description} · {item.eta} min · <Users className="inline h-3 w-3" /> {item.seats}</p></div><div className="text-right"><p className="font-bold">₦{item.price.toLocaleString()}</p>{option.id === item.id && <Check className="ml-auto mt-1 h-4 w-4 text-emerald-600" />}</div></button>)}</div>
        <div className="mt-6 rounded-2xl bg-slate-950 p-4 text-white"><div className="flex items-center justify-between text-sm"><span className="text-slate-400">Estimated fare</span><strong>₦{option.price.toLocaleString()}</strong></div><button disabled={loading || !dropoff.trim()} onClick={book} className="mt-4 w-full rounded-xl bg-emerald-500 px-4 py-3.5 text-sm font-bold text-white transition hover:bg-emerald-400 disabled:opacity-50">{loading ? 'Finding your driver…' : 'Confirm ride'}</button></div>
      </section>
    </main>
  </AppShell>
}

function Field({ icon: Icon, value, onChange, label, dark }) {
  return <label className="flex items-center gap-3"><span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${dark ? 'bg-slate-950 text-white' : 'bg-emerald-50 text-emerald-700'}`}><Icon className="h-4 w-4" /></span><span className="min-w-0 flex-1"><span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">{label}</span><input value={value} onChange={(e) => onChange(e.target.value)} className="mt-0.5 w-full bg-transparent text-sm font-semibold text-slate-800 outline-none" /></span></label>
}
