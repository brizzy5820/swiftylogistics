import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, CarFront, CheckCircle2, Clock3, Menu, PackageCheck, ShieldCheck, Smartphone } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '../components/ui/sheet'
import { ServiceGrid } from '../components/marketing/ServiceGrid'
import { Footer } from '../components/marketing/Footer'

export default function Index() {
  const { scrollY } = useScroll()
  const heroY = useTransform(scrollY, [0, 700], ['0%', '25%'])
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => scrollY.on('change', (value) => setScrolled(value > 40)), [scrollY])

  return <div className="min-h-screen overflow-x-hidden bg-white text-slate-900">
    <header className={`fixed inset-x-0 top-0 z-50 transition ${scrolled ? 'border-b border-slate-200/70 bg-white/90 shadow-sm backdrop-blur-xl' : 'bg-transparent'}`}>
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-10">
        <Link to="/" className={`text-2xl font-black tracking-tight ${scrolled ? 'text-slate-950' : 'text-white'}`}>swifty<span className="text-emerald-400">.</span></Link>
        <nav className={`hidden items-center gap-7 text-sm font-semibold md:flex ${scrolled ? 'text-slate-600' : 'text-white/90'}`}><a href="#services">Services</a><a href="#how">How it works</a><a href="#safety">Safety</a></nav>
        <div className="hidden items-center gap-2 sm:flex"><Link to="/auth" className={`rounded-full px-4 py-2 text-sm font-bold ${scrolled ? 'text-slate-700 hover:bg-slate-100' : 'text-white hover:bg-white/10'}`}>Log in</Link><Link to="/auth" className="rounded-full bg-emerald-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-900/20 transition hover:bg-emerald-400">Get started</Link></div>
        <Sheet><SheetTrigger asChild><button className={`rounded-xl p-2.5 sm:hidden ${scrolled ? 'text-slate-900' : 'text-white'}`} aria-label="Menu"><Menu /></button></SheetTrigger><SheetContent><SheetHeader><SheetTitle>swifty.</SheetTitle></SheetHeader><div className="mt-6 grid gap-2"><a href="#services" className="rounded-xl p-3 font-semibold">Services</a><a href="#how" className="rounded-xl p-3 font-semibold">How it works</a><Link to="/auth" className="mt-3 rounded-xl bg-emerald-600 p-3 text-center font-bold text-white">Get started</Link></div></SheetContent></Sheet>
      </div>
    </header>

    <section className="relative min-h-[760px] overflow-hidden bg-slate-950 text-white">
      <motion.div style={{ y: heroY }} className="absolute inset-0 scale-110 bg-[radial-gradient(circle_at_75%_30%,rgba(16,185,129,.34),transparent_28%),radial-gradient(circle_at_25%_75%,rgba(34,197,94,.18),transparent_28%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(120deg,#020617_15%,rgba(2,6,23,.75),#052e16)]" />
      <div className="relative z-10 mx-auto flex min-h-[760px] max-w-7xl items-center px-5 pb-16 pt-28 sm:px-8 lg:px-10">
        <div className="grid w-full gap-12 lg:grid-cols-[1.1fr_.9fr] lg:items-center">
          <div>
            <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-4 py-2 text-xs font-bold uppercase tracking-[.18em] text-emerald-300"><span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" /> One app. Every move.</motion.div>
            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .08 }} className="max-w-4xl font-display text-5xl font-black leading-[.98] tracking-[-.04em] sm:text-6xl lg:text-8xl">Move your world <span className="text-emerald-400">with Swifty.</span></motion.h1>
            <p className="mt-7 max-w-2xl text-base leading-7 text-slate-300 sm:text-lg">Book a ride, send a package, arrange a pickup or keep an eye on every trip — all from one clean, reliable platform.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row"><Link to="/auth" className="inline-flex items-center justify-center gap-2 rounded-full bg-emerald-500 px-7 py-4 text-sm font-bold text-white shadow-xl shadow-emerald-900/30 hover:bg-emerald-400">Start moving <ArrowRight className="h-4 w-4" /></Link><Link to="/auth" state={{ role: 'rider' }} className="inline-flex items-center justify-center gap-2 rounded-full border border-white/15 bg-white/5 px-7 py-4 text-sm font-bold text-white hover:bg-white/10">Become a rider</Link></div>
            <div className="mt-10 flex flex-wrap gap-x-7 gap-y-3 text-xs font-semibold text-slate-400"><span><CheckCircle2 className="mr-1 inline h-4 w-4 text-emerald-400" />Live tracking</span><span><CheckCircle2 className="mr-1 inline h-4 w-4 text-emerald-400" />Cashless-ready</span><span><CheckCircle2 className="mr-1 inline h-4 w-4 text-emerald-400" />24/7 support</span></div>
          </div>
          <div className="hidden lg:block"><HeroProductCard /></div>
        </div>
      </div>
    </section>

    <section className="border-b border-slate-200 bg-white py-14"><div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-6 sm:grid-cols-4 sm:px-8 lg:px-10"><Metric value="50k+" label="completed deliveries" /><Metric value="1.2k+" label="active riders" /><Metric value="4.9/5" label="average experience" /><Metric value="24/7" label="movement support" /></div></section>
    <section id="services" className="bg-slate-50 px-6 py-24 sm:px-8 lg:px-10"><div className="mx-auto max-w-7xl"><div className="max-w-2xl"><p className="text-sm font-bold uppercase tracking-[.18em] text-emerald-700">Everything in one place</p><h2 className="mt-3 font-display text-4xl font-black tracking-tight sm:text-5xl">More than delivery.</h2><p className="mt-4 text-base leading-7 text-slate-500">Swifty is evolving from a package service into a complete movement platform for everyday people and businesses.</p></div><div className="mt-10"><ServiceGrid /></div></div></section>
    <section id="how" className="px-6 py-24 sm:px-8 lg:px-10"><div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[.8fr_1.2fr] lg:items-center"><div><p className="text-sm font-bold uppercase tracking-[.18em] text-emerald-700">Simple by design</p><h2 className="mt-3 font-display text-4xl font-black tracking-tight sm:text-5xl">One flow for every journey.</h2><p className="mt-5 leading-7 text-slate-500">Whether you need a driver or a courier, the experience stays familiar: choose a service, set your destination, confirm and follow the progress.</p></div><div className="grid gap-4 sm:grid-cols-3"><Step n="01" icon={Smartphone} title="Choose" text="Select ride, delivery or another service." /><Step n="02" icon={MapPinIcon} title="Set the route" text="Tell us where to pick up and where to go." /><Step n="03" icon={Clock3} title="Move" text="Get live updates from start to finish." /></div></div></section>
    <section id="safety" className="bg-emerald-50 px-6 py-24 sm:px-8 lg:px-10"><div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-3"><Safety icon={ShieldCheck} title="Built around trust" text="Clear trip details, rider information and status updates keep everyone informed." /><Safety icon={PackageCheck} title="Every order visible" text="Track rides and deliveries from the same account instead of jumping between apps." /><Safety icon={CarFront} title="Ready to scale" text="The platform is structured for Express + MongoDB on the backend when live services are connected." /></div></section>
    <section className="bg-slate-950 px-6 py-24 text-center text-white sm:px-8"><div className="mx-auto max-w-3xl"><h2 className="font-display text-4xl font-black tracking-tight sm:text-6xl">Your next move starts here.</h2><p className="mx-auto mt-5 max-w-xl leading-7 text-slate-400">One account for rides, packages and the everyday journeys in between.</p><Link to="/auth" className="mt-8 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-7 py-4 text-sm font-bold hover:bg-emerald-400">Get started <ArrowRight className="h-4 w-4" /></Link></div></section>
    <Footer />
  </div>
}

function HeroProductCard() { return <div className="ml-auto max-w-md rounded-[2rem] border border-white/10 bg-white/[.07] p-4 shadow-2xl backdrop-blur-xl"><div className="rounded-[1.5rem] bg-white p-5 text-slate-900"><div className="flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-wider text-emerald-700">Swifty ride</p><h3 className="mt-1 font-display text-xl font-black">Driver arriving</h3></div><span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">4 min</span></div><div className="relative mt-5 h-56 overflow-hidden rounded-2xl bg-emerald-50"><div className="absolute inset-0 opacity-50" style={{ backgroundImage: 'linear-gradient(30deg, transparent 48%, #bbf7d0 49%, #bbf7d0 51%, transparent 52%), linear-gradient(120deg, transparent 48%, #bbf7d0 49%, #bbf7d0 51%, transparent 52%)', backgroundSize: '55px 55px' }} /><div className="absolute left-[18%] top-[66%] h-3 w-3 rounded-full bg-emerald-600 ring-8 ring-emerald-600/10" /><div className="absolute right-[20%] top-[25%] h-3 w-3 rounded-full bg-slate-900 ring-8 ring-slate-900/10" /></div><div className="mt-4 flex items-center justify-between"><div><p className="text-sm font-bold">Daniel O.</p><p className="text-xs text-slate-500">Toyota Corolla · 4.9 ★</p></div><div className="rounded-xl bg-slate-100 p-3"><CarFront className="h-5 w-5" /></div></div></div></div> }
function Metric({ value, label }) { return <div className="text-center"><p className="font-display text-3xl font-black tracking-tight sm:text-4xl">{value}</p><p className="mt-1 text-xs font-semibold uppercase tracking-wider text-slate-400">{label}</p></div> }
function Step({ n, icon: Icon, title, text }) { return <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200"><span className="text-xs font-black text-emerald-600">{n}</span><Icon className="mt-7 h-6 w-6 text-slate-900" /><h3 className="mt-5 font-display text-lg font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-500">{text}</p></div> }
function Safety({ icon: Icon, title, text }) { return <div className="rounded-3xl bg-white p-7 shadow-sm ring-1 ring-emerald-100"><Icon className="h-7 w-7 text-emerald-600" /><h3 className="mt-6 font-display text-xl font-bold">{title}</h3><p className="mt-3 text-sm leading-6 text-slate-500">{text}</p></div> }
function MapPinIcon(props) { return <span {...props} className={props.className}>⌖</span> }
