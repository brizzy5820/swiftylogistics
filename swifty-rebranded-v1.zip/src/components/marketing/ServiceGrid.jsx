import { BriefcaseBusiness, CarFront, Package, Route } from 'lucide-react'
import { Link } from 'react-router-dom'
import { MOCK_SERVICES } from '../../data/mock-data'

const ICONS = { car: CarFront, package: Package, route: Route, briefcase: BriefcaseBusiness }

export function ServiceGrid() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {MOCK_SERVICES.map((service) => {
        const Icon = ICONS[service.icon]
        return (
          <Link key={service.id} to={service.href} className="group rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200/70 transition hover:-translate-y-1 hover:shadow-xl">
            <div className="mb-7 flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700 transition group-hover:bg-emerald-600 group-hover:text-white">
              <Icon className="h-6 w-6" />
            </div>
            <h3 className="font-display text-lg font-bold text-slate-950">{service.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">{service.description}</p>
            <span className="mt-5 inline-flex text-sm font-bold text-emerald-700">Explore service →</span>
          </Link>
        )
      })}
    </div>
  )
}
