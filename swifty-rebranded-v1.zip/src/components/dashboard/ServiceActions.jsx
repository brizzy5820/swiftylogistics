import { ArrowUpRight, CarFront, PackagePlus, Route } from 'lucide-react'
import { Link } from 'react-router-dom'

export function ServiceActions() {
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Action to="/customer/ride" icon={CarFront} title="Book a ride" subtitle="A car is minutes away" primary />
      <Action to="/customer/book" icon={PackagePlus} title="Send a package" subtitle="Pickup and delivery" />
      <Action to="/customer/track" icon={Route} title="Track something" subtitle="Follow an active order" />
    </div>
  )
}

function Action({ to, icon: Icon, title, subtitle, primary }) {
  return <Link to={to} className={`group flex items-center gap-4 rounded-2xl p-4 transition hover:-translate-y-0.5 ${primary ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-white text-slate-900 ring-1 ring-slate-200 hover:shadow-lg'}`}>
    <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${primary ? 'bg-white/15' : 'bg-emerald-50 text-emerald-700'}`}><Icon className="h-5 w-5" /></span>
    <span className="min-w-0"><span className="block text-sm font-bold">{title}</span><span className={`mt-0.5 block truncate text-xs ${primary ? 'text-emerald-50' : 'text-slate-500'}`}>{subtitle}</span></span>
    <ArrowUpRight className="ml-auto h-4 w-4 opacity-60 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
  </Link>
}
