import { useParams, useNavigate, useLocation, Link } from 'react-router-dom'
import { useEffect, useState, useCallback, useRef } from 'react'
import { Phone, X, CheckCircle, ArrowLeft, ClipboardList, UserCheck, Package, Truck, Copy, MapPinned, LoaderCircle, MapPin, Search } from 'lucide-react'
import { AppShell } from '@/components/app-shell'
import { DeliveryMap } from '@/components/delivery-map'
import { MobileDrawer } from '@/components/mobile-drawer'
import { TripCard } from '@/components/trip-card'
import { ChatPanel, ChatLauncher } from '@/components/chat-panel'
// Trip tracking is publicly viewable by code; only the "my trips" list requires sign-in.
import { useStore, useCurrentUser, updateDeliveryStatus, confirmOrder, STATUS_LABEL } from '@/lib/api-store'
import { getErrorMessage, getPublicTracking } from '@/services/api'
import { getSocket } from '@/lib/socket'
import { Skeleton, SkeletonText, SkeletonCard, SkeletonAvatar, SkeletonMap, SkeletonListItem } from '@/components/ui/skeleton'

function formatTime(ts) {
  if (!ts) return null
  return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

const POLLING_INTERVAL_MS = 5000

export default function Track() {
  const { user, loading } = useCurrentUser()
  const { id } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const [copied, setCopied] = useState(false)
  const [lookupSettled, setLookupSettled] = useState(false)
  const [trackingCode, setTrackingCode] = useState('')
  const [outcomeBannerDismissed, setOutcomeBannerDismissed] = useState(false)
  const [publicDelivery, setPublicDelivery] = useState(null)
  const [errorMessage, setErrorMessage] = useState('')
  const [chatOpen, setChatOpen] = useState(false)
  const [chatUnread, setChatUnread] = useState(false)
  const deliveries = useStore((s) => (user ? s.deliveries.filter((d) => d.customerId === user.id) : []))
  const delivery = useStore((s) => s.deliveries.find((d) => d.id === id || d.aciveTrackingId === id))
  const pollingRef = useRef(null)
  const confirmedRef = useRef(new Set())

  useEffect(() => {
    if (!id || delivery || !id.startsWith('TRK-') && !id.startsWith('RIDE-')) return
    let active = true
    getPublicTracking(id).then((data) => { if (active) setPublicDelivery(data.tracking) }).catch((error) => {
      if (active) setErrorMessage(getErrorMessage(error, 'Unable to load tracking details.'))
    })
    return () => { active = false }
  }, [id, delivery])
  
  const effectiveDelivery = delivery || publicDelivery
  const trackingId = location.state?.trackingId ?? effectiveDelivery?.trackingId ?? id
  const deliveryId = effectiveDelivery?.id
  const deliveryView = effectiveDelivery

  // Landing on the live track page with a rider already assigned counts as
  // the customer's confirmation — this is what unlocks "Start trip" on the
  // rider's side (server-enforced; see rider.services.js).
  useEffect(() => {
    if (!user || !deliveryView) return
    if (!deliveryView.riderName || deliveryView.customerConfirmed) return
    if (confirmedRef.current.has(deliveryView.id)) return
    confirmedRef.current.add(deliveryView.id)
    confirmOrder(deliveryView.id).catch(() => confirmedRef.current.delete(deliveryView.id))
  }, [user, deliveryView?.id, deliveryView?.riderName, deliveryView?.customerConfirmed])

  // Show an unread dot on the chat launcher when a message arrives while
  // the panel is closed.
  useEffect(() => {
    const socket = getSocket()
    if (!socket || !deliveryId || chatOpen) return
    const handler = (message) => {
      if (message.orderId === deliveryId && String(message.sender) !== String(user?.id)) setChatUnread(true)
    }
    socket.on('chat:message', handler)
    return () => socket.off('chat:message', handler)
  }, [deliveryId, chatOpen, user?.id])

  // Polling for public tracking real-time updates (when user is not logged in or tracking public link)
  useEffect(() => {
    if (!deliveryId || !deliveryView || user) return
    
    const statusesToPoll = ['pending', 'accepted', 'picked_up', 'in_transit']
    if (!statusesToPoll.includes(deliveryView.status)) return

    const poll = async () => {
      try {
        const data = await getPublicTracking(deliveryId)
        if (data?.tracking && data.tracking.status !== deliveryView.status) {
          setPublicDelivery(data.tracking)
        }
      } catch (error) {
        console.error('Polling failed:', error)
      }
    }

    // Initial poll
    poll()
    
    // Set up interval
    pollingRef.current = setInterval(poll, POLLING_INTERVAL_MS)
    
    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current)
      }
    }
  }, [deliveryId, deliveryView?.status, user])

  const searchParams = new URLSearchParams(location.search)
  const requestedTab = searchParams.get('tab')
// top of Track component, alongside your other state
const [sheetHeightPx, setSheetHeightPx] = useState(0)
const [sheetDragging, setSheetDragging] = useState(true)
const handleSheetHeightChange = useCallback((px, dragging = true) => {
  setSheetHeightPx(px)
  setSheetDragging(Boolean(dragging))
}, [])
  // Auto-advance removed: the real logged-in rider now drives status progression
  // from their dashboard. The store's listener system broadcasts changes here reactively.

  useEffect(() => {
    setLookupSettled(false)
    const timeout = window.setTimeout(() => setLookupSettled(true), 600)
    return () => window.clearTimeout(timeout)
  }, [id])

  useEffect(() => {
    if (!copied) return
    const timeout = window.setTimeout(() => setCopied(false), 1800)
    return () => window.clearTimeout(timeout)
  }, [copied])

  useEffect(() => {
    setOutcomeBannerDismissed(false)
  }, [deliveryId, deliveryView?.status])

  function handleCopy() {
    if (!trackingId) return
    navigator.clipboard?.writeText(trackingId).then(() => setCopied(true))
  }

  function handleTrackLookup(event) {
    event.preventDefault()
    const value = trackingCode.trim()
    if (!value) return
    navigate(`/customer/track/${encodeURIComponent(value)}`, { state: { trackingId: value } })
  }

  if (!user && !id) {
    return (
      <AppShell>
        <main className="mx-auto flex min-h-[60vh] max-w-3xl flex-col items-center justify-center px-6 py-12 text-center">
          <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-100 text-slate-500">
            <MapPinned className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Sign in to see your trips</h1>
          <p className="mt-2 text-sm text-slate-500">Log in to view the rides and deliveries linked to your account, or use a tracking code above to follow any trip live.</p>
          <Link to="/auth" state={{ from: '/customer/track', intent: { trackingId: trackingCode || undefined } }} className="mt-6 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-6 py-3 text-sm font-bold text-white transition hover:bg-emerald-500">Log in</Link>
        </main>
      </AppShell>
    )
  }

  // Show skeleton while user is loading
  if (loading) {
    return (
      <AppShell>
        <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="mb-6 flex flex-col gap-2">
            <Skeleton className="h-8 w-48 rounded-xl" />
            <Skeleton className="h-4 w-64 rounded" />
          </div>
          <SkeletonCard />
          <div className="mt-6 space-y-3">
            {[1, 2, 3].map((i) => (
              <SkeletonListItem key={i} />
            ))}
          </div>
        </main>
      </AppShell>
    )
  }

  const handleBack = () => {
     if(id){
        navigate('/customer/history')
    }
    else if (window.history.state && window.history.state.idx > 0) {
      navigate(-1)
    } else {
      navigate('/customer/history')
    }
   
  }

  if (!id) {
    const orderedDeliveries = [...deliveries].sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
    const tabDefinitions = [
      {
        key: 'in_transit',
        label: 'In transit',
        items: orderedDeliveries.filter((item) => item.status === 'in_transit'),
      },
      {
        key: 'active',
        label: 'Active',
        items: orderedDeliveries.filter((item) => item.status !== 'delivered' && item.status !== 'cancelled'),
      },
      {
        key: 'delivered',
        label: 'Delivered',
        items: orderedDeliveries.filter((item) => item.status === 'delivered'),
      },
    ]
    const visibleTabs = tabDefinitions.filter((tab) => tab.items.length > 0)
    const activeTab = visibleTabs.some((tab) => tab.key === requestedTab)
      ? requestedTab
      : visibleTabs[0]?.key
    const displayedDeliveries = activeTab
      ? visibleTabs.find((tab) => tab.key === activeTab)?.items ?? []
      : orderedDeliveries

    return (
      <AppShell>
        <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={handleBack}
            aria-label="Go back"
            className="mb-5 inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50 hover:text-slate-900"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="mb-6 flex flex-col gap-2">
            <h1 className="text-2xl text-left sm:text-left font-bold text-slate-900">Track </h1>
            <p className="text-sm  text-left text-slate-500">Track a delivery to receive package</p>
          </div>

          <form onSubmit={handleTrackLookup} className="mb-6 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm sm:flex sm:items-center sm:gap-3">
            <div className="relative min-w-0 flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                value={trackingCode}
                onChange={(event) => setTrackingCode(event.target.value)}
                placeholder="Enter tracking code"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-emerald-600 focus:bg-white"
              />
            </div>
            <button type="submit" className="mt-3 inline-flex w-full items-center justify-center rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-emerald-500 sm:mt-0 sm:w-auto">
              Track now
            </button>
          </form>

          {visibleTabs.length > 0 && (
            <div className="mb-5 grid grid-cols-3 gap-2 rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm">
              {visibleTabs.map((tab) => (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => navigate(`/customer/track?tab=${tab.key}`)}
                  className={`min-w-0 rounded-xl px-2 py-2.5 text-center text-[11px] font-bold flex items-center justify-center gap-3 transition-colors sm:text-sm ${
                    activeTab === tab.key
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <span className=" truncate">{tab.label}</span>
                  <span className={`mt-0.5text-[10px] ${activeTab === tab.key ? 'text-white/70' : 'text-slate-400'}`}>
                    {tab.items.length}
                  </span>
                </button>
              ))}
            </div>
          )}

          <div className="space-y-3">
            {orderedDeliveries.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-500">
                  <MapPin className="h-6 w-6" />
                </div>
                <h2 className="mt-4 text-lg font-semibold text-slate-900">No activity yet</h2>
                <p className="mt-2 text-sm text-slate-500">Your shipment updates will appear here once a booking is created.</p>
              </div>
            ) : (
              displayedDeliveries.map((item) => (
                <TripCard key={item.id} delivery={item} actionTo={`/customer/track/${item.id}`} />
              ))
            )}
          </div>
        </main>
      </AppShell>
    )
  }

  if (!effectiveDelivery && !lookupSettled)
    return (
      <AppShell>
        <main className="mx-auto flex max-w-3xl flex-col items-center justify-center px-6 py-12 text-center">
          <SkeletonAvatar size="xl" className="mx-auto" />
          <SkeletonText lines={2} className="mt-4 max-w-md mx-auto" />
        </main>
      </AppShell>
    )

  if (!effectiveDelivery)
    return (
      <AppShell>
        <main className="mx-auto flex  max-w-3xl flex-col items-center justify-center px-6 py-12 text-center">
          <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-100 text-slate-500">
            <MapPinned className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">No shipment found</h1>
          <p className="mt-2 text-sm text-slate-500">{errorMessage || 'This tracking link does not match a live delivery yet.'}</p>
          <button onClick={handleBack} className="mt-6 inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50 hover:text-slate-900">
            <ArrowLeft className="h-4 w-4" />
          </button>
        </main>
      </AppShell>
    )

  const isCancelled = deliveryView.status === 'cancelled'
  const isDelivered = deliveryView.status === 'delivered'
  const riderAssigned = !!deliveryView.riderName
  // Check if terminated: rider cancelled or no driver found (pending but no rider assigned after timeout)
  const isTerminated = isCancelled || (deliveryView.status === 'pending' && !riderAssigned && deliveryView.timedOut)
  const canCancel = Boolean(user) && deliveryView.status === 'pending'
  const canContact = riderAssigned && !isDelivered && !isCancelled && !isTerminated

  const steps = [
    { key: 'pending', label: 'Order placed', Icon: ClipboardList },
    { key: 'accepted', label: 'Rider accepted', Icon: UserCheck },
    { key: 'picked_up', label: 'Picked up', Icon: Package },
    { key: 'in_transit', label: 'In transit', Icon: Truck },
    { key: 'delivered', label: 'Delivered', Icon: CheckCircle },
  ]
  const currentIdx = steps.findIndex((s) => s.key === deliveryView.status)

  async function handleCancel() {
    setErrorMessage('')
    try {
      await updateDeliveryStatus(deliveryView.id, 'cancelled')
    } catch (error) {
      setErrorMessage(getErrorMessage(error, 'Unable to cancel this order.'))
    }
  }

  const banner = !outcomeBannerDismissed && isDelivered ? (
    <div className="flex items-center gap-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-5 pr-3 shadow-lg shadow-emerald-900/5">
      <CheckCircle className="h-8 w-8 shrink-0 text-emerald-600" />
      <div className="min-w-0 flex-1">
        <p className="font-bold text-emerald-700 text-lg">Package delivered!</p>
        <p className="text-sm text-slate-600 mt-0.5">Your delivery has been completed successfully.</p>
      </div>
      <button
        type="button"
        onClick={() => setOutcomeBannerDismissed(true)}
        aria-label="Close delivered indicator"
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/80 text-emerald-700 transition-colors hover:bg-white"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  ) : !outcomeBannerDismissed && isCancelled ? (
    <div className="flex items-center gap-4 rounded-2xl bg-red-50 border border-red-200 p-5 pr-3 shadow-lg shadow-red-900/5">
      <X className="h-8 w-8 shrink-0 text-red-500" />
      <div className="min-w-0 flex-1">
        <p className="font-bold text-red-600 text-lg">Order cancelled</p>
        <p className="text-sm text-slate-600 mt-0.5">This delivery has been cancelled.</p>
      </div>
      <button
        type="button"
        onClick={() => setOutcomeBannerDismissed(true)}
        aria-label="Close cancelled indicator"
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/80 text-red-600 transition-colors hover:bg-white"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  ) : null

  function DetailPanel() {
    return (
      <div className='flex flex-col gap-3 ' >
        {/* Status card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Status</p>
              <p className={`mt-1 font-display text-2xl font-bold ${isCancelled || isTerminated ? 'text-red-500' : isDelivered ? 'text-emerald-600' : 'text-emerald-600'}`}>
                {isTerminated ? 'Terminated' : STATUS_LABEL[deliveryView.status]}
              </p>
            </div>
            <button onClick={handleCopy} className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-50">
              <Copy className="h-3.5 w-3.5" /> {copied ? 'Copied' : 'Copy ID'}
            </button>
          </div>
          <p className="mt-2 text-sm text-slate-500">Tracking ID · {trackingId}</p>
          {!isDelivered && !isCancelled && !isTerminated && (
            <p className="mt-1 text-sm text-slate-500">ETA · {deliveryView.etaMinutes} min</p>
          )}

          {!isCancelled && !isTerminated && (
            <ol className="mt-6 space-y-3">
              {steps.map((s, i) => {
                const done = i <= currentIdx
                const isCurrent = i === currentIdx && !isDelivered
                const timestamp = deliveryView.statusTimestamps?.[s.key]
                const { Icon } = s
                return (
                  <li key={s.key} className="flex items-start gap-3">
                    <span
                      className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-colors ${
                        done
                          ? isDelivered
                            ? 'bg-emerald-600 text-white'
                            : 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-400'
                      } ${isCurrent ? 'ring-4 ring-emerald-600/20' : ''}`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                    </span>
                    <div className="min-w-0">
                      <p className={`text-sm ${done ? 'font-bold text-slate-900' : 'text-slate-400'}`}>{s.label}</p>
                      <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-slate-400">
                        {timestamp ? formatTime(timestamp) : isCurrent ? 'In progress' : 'Pending'}
                      </p>
                    </div>
                  </li>
                )
              })}
            </ol>
          )}
          {isTerminated && (
            <p className="mt-4 text-center text-red-500 font-semibold">This ride was terminated - no driver was assigned or the driver cancelled</p>
          )}
        </div>

        {/* Courier card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Your courier</p>
          <div className="mt-3 flex items-center gap-4">
            <div className="size-12 rounded-xl bg-emerald-50 flex items-center justify-center font-bold text-emerald-600">
              {(deliveryView.riderName ?? '—').split(' ').map((n) => n[0]).join('').slice(0, 2)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate">
                {isTerminated ? 'Terminated' : deliveryView.riderName ?? 'Awaiting rider…'}
              </p>
              {riderAssigned && !isTerminated && (
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <p className="text-xs text-amber-500">★ 4.9 <span className="text-slate-400">(1,240 trips)</span></p>
                  {deliveryView.rider?.plateNumber && (
                    <span className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {deliveryView.rider.plateNumber}
                    </span>
                  )}
                </div>
              )}
            </div>
            {canContact && (
              <div className="flex items-center gap-2">
                <ChatLauncher hasUnread={chatUnread} onClick={() => { setChatOpen(true); setChatUnread(false) }} />
                {deliveryView.rider?.phone && (
                  <a
                    href={`tel:${deliveryView.rider.phone}`}
                    className="flex items-center justify-center size-10 rounded-full bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                    title="Call rider"
                  >
                    <Phone className="h-4 w-4" />
                  </a>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Delivery details card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400">From</p>
            <p className="text-sm font-medium">{deliveryView.pickup.address}</p>
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400">To</p>
            <p className="text-sm font-medium">{deliveryView.dropoff.address}</p>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-slate-200">
            <span className="text-xs text-slate-500">{deliveryView.type === 'ride' ? `Ride · ${deliveryView.rideType || ''}` : `Delivery · ${deliveryView.packageType || ''}`} · {deliveryView.distanceKm} km</span>
            <span className="font-display font-bold">₦{deliveryView.price}</span>
          </div>
        </div>

        {errorMessage && (
          <p className="whitespace-pre-line rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">
            {errorMessage}
          </p>
        )}

        {/* Cancel button — only for pending */}
        {canCancel && (
          <button
            onClick={handleCancel}
            className="w-full flex items-center justify-center gap-2 rounded-xl border border-red-200 py-3 text-sm font-bold text-red-500 hover:bg-red-50 transition-colors"
          >
            <X className="h-4 w-4" /> Cancel order
          </button>
        )}
      </div>
    )
  }

  const livePill = (
    <div className="flex items-center gap-2 rounded-full px-4">
      <div className={`size-2 rounded-full ${isCancelled ? 'bg-red-400' : isDelivered ? 'bg-emerald-500' : 'bg-emerald-500 animate-pulse'}`} />
      <span className="text-2xs text-gray-100 lg:text-black font-bold">Live · {deliveryView.id}</span>
    </div>
  )

  return (
    <>
      {/* ── Mobile: full-bleed map with a draggable bottom sheet ── */}
   <div className="lg:hidden h-full">
   <div className={`fixed inset-x-0 top-0 z-100 lg:hidden ${sheetDragging ? '' : 'transition-[bottom] duration-200 ease-out'}`}>
    {/* Map fills the screen from the top down to wherever the drawer
        currently starts. bottom = sheetHeightPx, so dragging the sheet
        down shrinks its height -> bottom shrinks -> map grows, and
        dragging up does the reverse. No transition while actively
        dragging (must track the finger 1:1); animates on snap. */}
    <div
      className={`fixed inset-x-0 top-0 ${sheetDragging ? '' : 'transition-[bottom] duration-200 ease-out'}`}
      style={{ bottom: sheetHeightPx }}
    >
      <DeliveryMap
        pickup={deliveryView.pickup.coords}
        dropoff={deliveryView.dropoff.coords}
        courier={deliveryView.courierPosition}
        courierInfo={{ riderName: deliveryView.riderName, rideType: deliveryView.rideType, phone: deliveryView.rider?.phone }}
        destination={deliveryView.dropoff.coords}
        pickupAddress={deliveryView.pickup.address}
        dropoffAddress={deliveryView.dropoff.address}
        className="h-full w-full"
      />
    </div>

    <div className="relative  flex items-center justify-between p-4">
      <button
        type="button"
        onClick={handleBack}
        aria-label="Go back"
        className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50 hover:text-slate-900"
      >
        <ArrowLeft className="h-4 w-4" />
      </button>
    
    </div>
  </div>

  {/* NOTE: banner is rendered inside the shared mobile drawer. */}
  <MobileDrawer
    banner={banner}
    initialSnapIndex={1}
    snapPoints={[14, 52, 88]}
    onHeightChange={handleSheetHeightChange}
  >
    <DetailPanel />
  </MobileDrawer>
</div>
      {/* ── Desktop: side-by-side grid (no drag — real layout space, not a floating sheet) ── */}
      <main className="hidden px-4 mt-4 sm:px-6 lg:px-8 py-6 max-w-7xl lg:py-3 mx-auto lg:block">
      
        {banner && <div className="mb-6">{banner}</div>}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <aside className="lg:col-span-4 space-y-6 overflow-y-auto h-screen">
           
          <div className='flex '>   
          <button
            type="button"
            onClick={handleBack}
            aria-label="Go back"
            className="inline-flex h-10 w-10 items-center justify-center text-slate-600 transition hover:bg-slate-50 hover:text-slate-900"
          >
            <ArrowLeft className="h-6 w-6" />
          </button>  {livePill}</div>   
              <DetailPanel />
            </aside>
            <section className="relative h-[50vh] sm:h-[60vh] lg:sticky lg:top-24 lg:col-span-8 lg:h-[calc(100vh-7rem)]">
              <DeliveryMap
                pickup={deliveryView.pickup.coords}
                dropoff={deliveryView.dropoff.coords}
                courier={deliveryView.courierPosition}
                courierInfo={{ riderName: deliveryView.riderName, rideType: deliveryView.rideType, phone: deliveryView.rider?.phone }}
                destination={deliveryView.dropoff.coords}
                pickupAddress={deliveryView.pickup.address}
                dropoffAddress={deliveryView.dropoff.address}
                className="h-full"
              />
            </section>
          </div>
      </main>

      {canContact && (
        <ChatPanel
          orderId={deliveryView.id}
          currentUserId={user?.id}
          otherPartyLabel={deliveryView.riderName || 'Your rider'}
          open={chatOpen}
          onOpenChange={setChatOpen}
        />
      )}
    </>
  )
}
