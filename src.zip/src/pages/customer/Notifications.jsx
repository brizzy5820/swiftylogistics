import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { Bell, Clock3, PackageCheck, Truck, ArrowLeft, LoaderCircle } from 'lucide-react'
import { AppShell} from '@/components/app-shell'
import { useRequireAuth } from '@/lib/use-require-auth'
import { useStore } from '@/lib/mock-store'
import { getDeliveries } from '@/services/api'

const NOTIFICATION_READ_KEY = 'swifty-notifications-read-at'

function formatTime(value) {
  if (!value) return ''
  return new Date(value).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })
}

function dayGroup(value) {
  const startOfDay = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
  const diffDays = Math.round((startOfDay(new Date()) - startOfDay(new Date(Number(value)))) / 86400000)
  if (diffDays <= 0) return 'Today'
  if (diffDays === 1) return 'Yesterday'
  return 'Earlier'
}

export default function NotificationsPage() {
  const navigate= useNavigate()
  const user = useRequireAuth('customer')
  const [readAt, setReadAt] = useState(() => {
    if (typeof window === 'undefined') return 0
    return Number(window.localStorage.getItem(NOTIFICATION_READ_KEY)) || 0
  })
  const [loading, setLoading] = useState(true)
  const deliveries = useStore((s) => (user ? s.deliveries.filter((d) => d.customerId === user.id) : []))

  useEffect(() => {
    if (!user) return undefined
    let cancelled = false
    setLoading(true)
    getDeliveries().finally(() => {
      if (!cancelled) setLoading(false)
    })
    return () => { cancelled = true }
  }, [user?.id])

  const notifications = useMemo(() => {
    if (!deliveries.length) return []

    const items = []
    deliveries.forEach((delivery) => {
      if (delivery.createdAt) {
        items.push({
          id: `${delivery.id}-created`,
          title: 'Order booked',
          description: `${delivery.id} was booked and is waiting for the next update.`,
          time: delivery.createdAt,
          icon: Bell,
        })
      }

      const timestamps = delivery.statusTimestamps ?? {}
      if (timestamps.accepted) {
        items.push({
          id: `${delivery.id}-accepted`,
          title: 'Rider accepted',
          description: `${delivery.id} was accepted by your rider.`,
          time: timestamps.accepted,
          icon: PackageCheck,
        })
      }
      if (timestamps.picked_up) {
        items.push({
          id: `${delivery.id}-picked-up`,
          title: 'Picked up',
          description: `${delivery.id} has been picked up and is on the way.`,
          time: timestamps.picked_up,
          icon: Truck,
        })
      }
      if (timestamps.in_transit) {
        items.push({
          id: `${delivery.id}-in-transit`,
          title: 'In transit',
          description: `${delivery.id} is now moving toward its destination.`,
          time: timestamps.in_transit,
          icon: Truck,
        })
      }
      if (timestamps.delivered) {
        items.push({
          id: `${delivery.id}-delivered`,
          title: 'Delivered',
          description: `${delivery.id} was completed successfully.`,
          time: timestamps.delivered,
          icon: PackageCheck,
        })
      }
    })

    return items.sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 12)
  }, [deliveries])

  if (!user) return null

  const latestNotificationTime = notifications.reduce((latest, item) => Math.max(latest, Number(item.time) || 0), 0)

  function markAllRead() {
    const nextReadAt = Date.now()
    window.localStorage.setItem(NOTIFICATION_READ_KEY, String(nextReadAt))
    setReadAt(nextReadAt)
    window.dispatchEvent(new Event('swifty:notifications-read'))
  }
  const handleBack = () => {
    if (window.history.state && window.history.state.idx > 0) {
      navigate(-1)
    } else {
      navigate('/customer')
    }
  }
  return (
    <AppShell hideMobileHeader>
      <main className="mx-auto max-w-4xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-center justify-between gap-3">
          <div className='flex gap-3 item-center'>
            <button
              type="button"
              onClick={handleBack}
              aria-label="Go back"
              className=" inline-flex  items-center justify-center rounded-full  text-slate-600 transition hover:bg-slate-50 hover:text-slate-900"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>{" "}
            <h1 className="text-2xl font-bold text-slate-900">Notification</h1>
          </div>
          {notifications.length > 0 && (
            <button
              type="button"
              onClick={markAllRead}
              className="rounded-full border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-900 shadow-sm transition hover:bg-emerald-50"
            >
              Read all
            </button>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-3 rounded-2xl border border-slate-200 bg-white p-10 text-sm text-slate-500 shadow-sm">
            <LoaderCircle className="h-5 w-5 animate-spin" />
            Loading your notifications...
          </div>
        ) : notifications.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-500">
              <Bell className="h-6 w-6" />
            </div>
            <h2 className="mt-4 text-lg font-semibold text-slate-900">No activity yet</h2>
            <p className="mt-2 text-sm text-slate-500">
              Your shipment updates will appear here once a booking is created.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map((item, index) => {
              const Icon = item.icon;
              const group = dayGroup(item.time);
              const showHeader = index === 0 || group !== dayGroup(notifications[index - 1].time);
              return (
                <div key={item.id}>
                  {showHeader && (
                    <p className="mb-2 mt-5 text-xs font-bold uppercase tracking-wider text-slate-400 first:mt-0">
                      {group}
                    </p>
                  )}
                  <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                    <div className="flex items-start gap-3">
                      <div
                        className={`relative flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${Number(item.time) > readAt ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-600"}`}
                      >
                        {Number(item.time) > readAt && (
                          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500" />
                        )}
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-semibold text-slate-900">{item.title}</p>
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-400">
                            <Clock3 className="h-3 w-3" />
                            {formatTime(item.time)}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-slate-600">{item.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </AppShell>
  );
}
