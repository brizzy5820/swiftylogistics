import { useMemo } from 'react'
import { ArrowRight, PackageCheck, Search } from 'lucide-react'
import { Link } from 'react-router-dom'
import { AppShell } from '../../components/app-shell'
import { ServiceActions } from '../../components/dashboard/ServiceActions'
import { RideTracker } from '../../components/dashboard/RideTracker'
import { useRequireAuth } from '../../lib/use-require-auth'
import { useStore } from '../../lib/mock-store'

export default function CustomerDashboard() {
  const user = useRequireAuth('customer')
  const deliveries = useStore((s) => user ? s.deliveries.filter((d) => d.customerId === user.id) : [])
  if (!user) return null
  const firstName = user.name.split(' ')[0]
  const recent = deliveries.slice(0, 3)

  return <AppShell>
    <main className="px-4 py-6 sm:px-6 lg:px-8">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <section className="space-y-6">
          <div className="rounded-3xl bg-emerald-700 p-6 text-white shadow-xl shadow-slate-900/10 sm:p-8">
            <div className="flex flex-col justify-between gap-8 sm:flex-row sm:items-end">
              <div><h1 className="mt-2 max-w-xl font-display text-3xl font-black tracking-tight sm:text-4xl">Good to see you, {firstName} </h1><p className="mt-3 max-w-xl text-sm leading-6 text-slate-200">Ride across town, send a package, or track something already on its way.</p></div>
            </div>
            <div className="mt-8 flex max-w-xl items-center gap-3 rounded-2xl bg-white/10 p-2 ring-1 ring-white/10"><Search className="ml-2 h-4 w-4 text-slate-400" /><input placeholder="Search destination, tracking ID or service" className="min-w-0 flex-1 bg-transparent px-1 py-2 text-sm text-white outline-none placeholder:text-slate-300" /><button className="rounded-xl bg-white px-4 py-2 text-xs font-bold text-slate-900">Search</button></div>
          </div>
          <ServiceActions />
          <section><div className="mb-3 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Your activity</p><h2 className="mt-1 font-display text-xl font-bold">Recent orders</h2></div><Link to="/customer/history" className="text-sm font-bold text-emerald-700">See all</Link></div><div className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200/70">{recent.length ? recent.map((item) => <Link key={item.id} to={`/customer/track/${item.id}`} className="flex items-center gap-4 border-b border-slate-100 p-4 last:border-0 hover:bg-slate-50"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700"><PackageCheck className="h-5 w-5" /></span><span className="min-w-0 flex-1"><span className="block text-sm font-bold">{item.pickup.address} → {item.dropoff.address}</span><span className="mt-1 block text-xs text-slate-500">{item.trackingId} · {item.status.replaceAll('_', ' ')}</span></span><ArrowRight className="h-4 w-4 text-slate-400" /></Link>) : <div className="p-8 text-center text-sm text-slate-500">Your recent orders will appear here.</div>}</div></section>
        </section>
        <aside className="order-first lg:order-none">
          <div className="lg:sticky lg:top-24">
            <RideTracker />
          </div>
        </aside>
      </div>
    </main>
  </AppShell>
}
